package com.changing.esun.jenkins.unit;

import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;

import javax.xml.rpc.holders.BooleanHolder;
import javax.xml.rpc.holders.StringHolder;
import javax.xml.ws.Holder;

import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.tempuri.SmsWebService;
import org.tempuri.SmsWebServiceSoap;

import com.changing.esun.SMs;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import junit.framework.TestCase;

public class APITest extends TestCase{
	
	public String uri = "https://sms.esunbank.com.tw/SmsWebService.asmx?WSDL";
	public String account = "Test001";
	public String SRT = "Testpassword";

	StubSMs stubSMs = null;
	SmsWebService ss = mock(SmsWebService.class);
	SmsWebServiceSoap port = mock(SmsWebServiceSoap.class);
	
	String result = null;
	
	Holder<Boolean> sendSMResult = new Holder<Boolean>();
	Holder<String> sendResult = new Holder<String>();
	Holder<String> esunMsgId = new Holder<String>();
	Holder<String> ispMsgId = new Holder<String>();
	Holder<String> statusCode = new Holder<String>();
	Holder<String> errorMsg = new Holder<String>();
	Holder<String> statusFlag = new Holder<String>();
	Holder<String> sendStatus = new Holder<String>();
	
	@Test
	public void testPositive_SendSM() {
		System.out.println("============Start Positive_TestSendSM============");	
			
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
							payBranch,
							phoneNo,
							smBody,
							mask,
							maskSmBody,
							smType,
							forceSend,
							orderTime,
							exprieTime,
							sysId,
							clientId,
							replyKafkaServer,
							replyTopic,
							customerId,
							profitUnit,
							eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Positive_TestSendSM============");	
		assertNotNull(result);
	}
	
	@Test
	public void testPositive_SendLongSM() {
		System.out.println("============Start Positive_SendLongSM============");	
			
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.My Text body will be longer than what you think.Must be over 70 word.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.My Text body will be longer than what you think.Must be over 70 word.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Positive_SendLongSM============");	
		assertNotNull(result);
	}
	

	@Test
	public void testNegative_SendSM_02() {
		System.out.println("============Start Negative_TestSendSM 02============");	
		System.out.println("#####  No PhoneNo");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 02============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66001", code);
	}
	
	@Test
	public void testNegative_SendSM_03() {
		System.out.println("============Start Negative_TestSendSM 03============");	
		System.out.println("#####  PhoneNo is not digits");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "acs09";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 03============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66003", code);
	}
	
	@Test
	public void testNegative_SendSM_04() {
		System.out.println("============Start Negative_TestSendSM 04============");	
		System.out.println("#####  No smBody");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 04============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66001", code);
	}
	
	@Test
	public void testNegative_SendSM_05() {
		System.out.println("============Start Negative_TestSendSM 05============");	
		System.out.println("#####  No smType");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 05============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66001", code);
	}
	
	@Test
	public void testNegative_SendSM_06() {
		System.out.println("============Start Negative_TestSendSM 06============");	
		System.out.println("#####  smType is not 1 or 2");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "0";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 06============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66003", code);
	}
	
	@Test
	public void testNegative_SendSM_07() {
		System.out.println("============Start Negative_TestSendSM 07============");	
		System.out.println("#####  orderTime is not correct");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "2019-02-28 162230";
		String exprieTime = "";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
					payBranch,
					phoneNo,
					smBody,
					mask,
					maskSmBody,
					smType,
					forceSend,
					orderTime,
					exprieTime,
					sysId,
					clientId,
					replyKafkaServer,
					replyTopic,
					customerId,
					profitUnit,
					eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 07============");
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66003", code);
	}
	
	@Test
	public void testNegative_SendSM_08() {
		System.out.println("============Start Negative_TestSendSM 08============");	
		System.out.println("#####  exprieTime is not date");
		String campaignedId = "";
		String payBranch = "";
		String phoneNo = "0910123456";
		String smBody = "Hi! This is a test.";
		String mask = "Y";
		String maskSmBody = "Hi! This is a test.";
		String smType = "1";
		String forceSend = "Y";
		String orderTime = "";
		String exprieTime = "2019-02-28 162230";
		String sysId = "CH0025";
		String clientId = "0001";
		String replyKafkaServer = "";
		String replyTopic = "";
		String customerId = "";
		String profitUnit = "";
		String eventType = "01";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSendSmValue(campaignedId,
							payBranch,
							phoneNo,
							smBody,
							mask,
							maskSmBody,
							smType,
							forceSend,
							orderTime,
							exprieTime,
							sysId,
							clientId,
							replyKafkaServer,
							replyTopic,
							customerId,
							profitUnit,
							eventType);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("============End Negative_TestSendSM 08============");
		System.out.println(result);
		
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		assertNotNull(result);
		assertEquals("66003", code);
	}
	
	@Test
	public void testPositive_SearchSM() {
		System.out.println("============Start Positive_TestSearchSM============");
		
		String EsunMsgId = "123";
		String ispMsgId = "";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSearchSmValue(EsunMsgId, ispMsgId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("============End Positive_TestSearchSM============");
		
		assertNotNull(result);
	}
	
	
	@Test
	public void testNegative_SearchSM() {
		System.out.println("============Start Negative_TestSearchSM============");
		
		String EsunMsgId = "";
		String ispMsgId = "";
		
		try {
			stubSMs = new StubSMs(uri, account, SRT);
			stubSMs.setSmsWebService(ss);
			stubSMs.setSmsWebServiceSoap(port);
			initSearchSmValue(EsunMsgId, ispMsgId);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("============End Negative_TestSearchSM============");
		
		JsonElement jelement = new JsonParser().parse(result);
		JsonObject  jobject = jelement.getAsJsonObject();
		String code = jobject.get("statusCode").getAsString();
		
		assertNotNull(result);
		assertEquals("66001", code);
	}
	
	
	private void initSendSmValue(String campaignedId,
								 String payBranch,
								 String phoneNo,
								 String smBody,
								 String mask,
								 String maskSmBody,
								 String smType,
								 String forceSend,
								 String orderTime,
								 String exprieTime,
								 String sysId,
								 String clientId,
								 String replyKafkaServer,
								 String replyTopic,
								 String customerId,
								 String profitUnit,
								 String eventType) throws Exception {
		result = null;
		//when(ss.getSmsWebServiceSoap()).thenReturn(port);
		doAnswer((Answer<Void>) invocation -> {
	        Object[] arguments = invocation.getArguments();
	        if(arguments != null){

	        	BooleanHolder sendSMResult = (BooleanHolder) arguments[18];
	        	StringHolder sendResult = (StringHolder) arguments[19];
	        	StringHolder esunMsgId = (StringHolder) arguments[20];
	        	StringHolder ispMsgId = (StringHolder) arguments[21];
	        	StringHolder statusCode = (StringHolder) arguments[22];
	        	StringHolder errorMsg = (StringHolder) arguments[23];
	        	sendSMResult.value = true;
	        	statusCode.value = "0";

	            }
	            return null;
	        }
	    ).when(port).sendSMV3(Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.anyString(),
								Mockito.any(),
								Mockito.any(),
								Mockito.any(),
								Mockito.any(),
								Mockito.any(),
								Mockito.any());
		result = stubSMs.SendSm(campaignedId,
								payBranch,
								phoneNo,
								smBody,
								mask,
								maskSmBody,
								smType,
								forceSend,
								orderTime,
								exprieTime,
								sysId,
								clientId,
								replyKafkaServer,
								replyTopic,
								customerId,
								profitUnit,
								eventType);
		System.out.println(result);
	}
	
	private void initSearchSmValue(String EsunMsgId, String ispMsgId) throws Exception {
		result = null;

		doAnswer((Answer<Void>) invocation -> {
	        Object[] arguments = invocation.getArguments();
	        if(arguments != null){
	            
	        	BooleanHolder sendSMResult = (BooleanHolder) arguments[4];
	        	StringHolder sendResult = (StringHolder) arguments[5];
	        	StringHolder sendStatus = (StringHolder) arguments[6];
	        	StringHolder statusCode = (StringHolder) arguments[7];
	        	StringHolder statusFlag = (StringHolder) arguments[8];
	        	StringHolder errorMsg = (StringHolder) arguments[9];
	        	sendSMResult.value = true;
	        	statusCode.value = "0";
	        	statusFlag.value = "4";
	            }
	           return null;
	        }
	    ).when(port).qrySendStatus(Mockito.anyString(),
									Mockito.anyString(),
									Mockito.anyString(),
									Mockito.anyString(),
									Mockito.any(javax.xml.ws.Holder.class),
									Mockito.any(javax.xml.ws.Holder.class),
									Mockito.any(javax.xml.ws.Holder.class),
									Mockito.any(javax.xml.ws.Holder.class),
									Mockito.any(javax.xml.ws.Holder.class),
									Mockito.any(javax.xml.ws.Holder.class));
		
		
		result = stubSMs.SearchSm(EsunMsgId, ispMsgId);
		//verify(port).qrySendStatus(account, SRT, EsunMsgId, ispMsgId, sendSMResult, sendResult, sendStatus, statusCode, statusFlag, errorMsg);
	}



	class StubSMs extends SMs{

		public StubSMs(String uri, String username, String SRT) throws Exception {
			super(uri, username, SRT);
		}
		
		@Override
		public SmsWebService initSmsWebService(){
			return ss;			
		}
		
		@Override
		public SmsWebServiceSoap initSmsWebServiceSoap(){
			return port;			
		}
		
		public void setSmsWebService(SmsWebService ss) {
			this.ss = ss;
		}
		
		public void setSmsWebServiceSoap(SmsWebServiceSoap port) {
			this.port = port;
		}
		
		public void setSendSMResult(Holder<Boolean> sendSMResult) {
			this.sendSMResult = sendSMResult;
		}
	
	}
	
}

