package com.changing.esun;


import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.tempuri.SmsWebService;
import org.tempuri.SmsWebServiceSoap;

import com.google.gson.Gson;
import com.google.gson.JsonObject;


public class SMs {
	
	private static Logger catLog = LogManager.getLogger(SMs.class);
	private static Logger catLogOut = LogManager.getLogger("OutBound");
	private Long startTime;
	private Long endTime;
	
	
	/***************************************************************
	 *********           Variable for WebService          **********
	 ***************************************************************/
	
	private final Gson gson;
	
	private static final QName SERVICE_NAME = new QName("http://tempuri.org/", "SmsWebService");
	
	private URL wsdlURL;
	private String userName;
	private String SRT;
	private String campaignedId;
	private String payBranch;
	private String phoneNo;
	private String smBody;
	private String mask;
	private String maskSmBody;
	private String smType;
	private String forceSend;
	private String orderTime;
	private String exprieTime;
	private String sysId;
	private String clientId;
	private String replyKafkaServer;
	private String replyTopic;
	private String customerId;
	private String profitUnit;
	private String eventType;

	public Holder<Boolean> sendSMResult = new Holder<Boolean>();
	public Holder<String> sendResult = new Holder<String>();
	public Holder<String> esunMsgId = new Holder<String>();
	public Holder<String> ispMsgId = new Holder<String>();
	public Holder<String> statusCode = new Holder<String>();
	public Holder<String> errorMsg = new Holder<String>();
	public Holder<String> statusFlag = new Holder<String>();
	public Holder<String> sendStatus = new Holder<String>();
	
	public SmsWebService ss;
	public SmsWebServiceSoap port;


	public SMs(String wsdlURL, String username, String SRT) throws Exception{
		catLog.trace("Create SMs Object for WebService.");
		startTime = System.currentTimeMillis();
		this.wsdlURL  = new URL(wsdlURL);
		
		ss = initSmsWebService();
		port = initSmsWebServiceSoap();

		this.userName = username;
		this.SRT = SRT;
		gson = new Gson();
	}
	
	public String SendSm(String campaignedId,
						 String payBranch,
						 String phoneNo,
						 String smBody,
						 String mask,
						 String maskSmBody,
						 String smType,
						 String forceSend,
						 String orderTime,
						 String exprieTime,
						 String sysId,
						 String clientId,
						 String replyKafkaServer,
						 String replyTopic,
						 String customerId,
						 String profitUnit,
						 String eventType) {
		catLog.info("Call get SendSm service");
		String result = "", logInfo = "[SendSms]";
		ResponseModel res = new ResponseModel();
		if(null == this.wsdlURL) {
			catLog.error("wsdlURL cannot be blank");
			res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
			res.setErrorMsg("wsdlURL cannot be blank");
		}else {
			if("Y".equalsIgnoreCase(mask)) {
				if(null == maskSmBody || maskSmBody.length() == 0) {
					catLog.error("maskSmBody cannot be blank");
					res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
					res.setErrorMsg("maskSmBody cannot be blank");
				}
			}
			
			if(null == phoneNo || phoneNo.length() == 0) {
				catLog.error("PhoneNo cannot be blank");
				res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
				res.setErrorMsg("PhoneNo cannot be blank");
			} else if(phoneNo.length() != 10 || !(phoneNo.substring(0, 1).equals("0"))) {
				catLog.error("PhoneNo must start with 0 and 10 digits");
				res.setStatusCode(ErrorCode.SERVER_RTN_ARGUMENT_ILLEGALE);
				res.setErrorMsg("PhoneNo must start with 0 and 10 digits");
			}else if(null == smBody || smBody.length() == 0) {
				catLog.error("smBody cannot be blank");
				res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
				res.setErrorMsg("smBody cannot be blank");
			} else if(!"Y".equalsIgnoreCase(mask) && !"N".equalsIgnoreCase(mask)) {
				catLog.error("mask must be Y or N");
				res.setStatusCode(ErrorCode.SERVER_RTN_ARGUMENT_ILLEGALE);
				res.setErrorMsg("mask must be Y or N");
			}  else if(null == smType || smType.length() == 0){
				catLog.error("smType cannot be blank");
				res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
				res.setErrorMsg("smType cannot be blank");
			}else if(Integer.parseInt(smType) < 1 || Integer.parseInt(smType) > 4){
				catLog.error("smType must be 1, 2, 3 or 4");
				res.setStatusCode(ErrorCode.SERVER_RTN_ARGUMENT_ILLEGALE);
				res.setErrorMsg("smType must be 1, 2, 3 or 4");
			} else if(null == sysId || sysId.length() == 0) {
				catLog.error("sysId cannot be blank");
				res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
				res.setErrorMsg("sysId cannot be blank");
			} else if(null == clientId || clientId.length() == 0) {
				catLog.error("clientId cannot be blank");
				res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
				res.setErrorMsg("clientId cannot be blank");
			} else {
				this.phoneNo = phoneNo;
				this.smBody = smBody;
				this.mask = mask;
				this.maskSmBody = maskSmBody;
				this.smType = smType;
				this.sysId = sysId;
				this.clientId = clientId;
				if(null == campaignedId || campaignedId.length() == 0) {
					this.campaignedId = "";
				} else {
					this.campaignedId = campaignedId;
				}
				if(null == payBranch || payBranch.length() == 0) {
					this.payBranch = "";
				} else {
					this.payBranch = payBranch;
				}
				if("Y".equals(forceSend)) {
					this.forceSend = "Y";
				} else {
					this.forceSend = "N";
				}
				if(null == orderTime || orderTime.length() == 0) {
					this.orderTime = "";
				} else {
					if(!isValidDate(orderTime)) {
						catLog.error("orderTime must be yyyyMMDDHHmmss");
						res.setStatusCode(ErrorCode.SERVER_RTN_ARGUMENT_ILLEGALE);
						res.setErrorMsg("orderTime must be yyyyMMDDHHmmss");
						this.orderTime = "";
					}
					this.orderTime = orderTime;
				}
				if(null == exprieTime || exprieTime.length() == 0) {
					this.exprieTime = "";
				} else {
					if(!isValidDate(exprieTime)) {
						catLog.error("exprieTime must be yyyyMMDDHHmmss");
						res.setStatusCode(ErrorCode.SERVER_RTN_ARGUMENT_ILLEGALE);
						res.setErrorMsg("expireTime must be yyyyMMDDHHmmss");
						this.exprieTime = "";
					}
					this.exprieTime = exprieTime;
				}
				if(null == replyKafkaServer || replyKafkaServer.length() == 0) {
					this.replyKafkaServer = "";
				} else {
					this.replyKafkaServer = replyKafkaServer;
				}
				if(null == replyTopic || replyTopic.length() == 0) {
					this.replyTopic = "";
				} else {
					this.replyTopic = replyTopic;
				}
				if(null == customerId || customerId.length() == 0) {
					this.customerId = "";
				} else {
					this.customerId = customerId;
				}
				if(null == profitUnit || profitUnit.length() == 0) {
					this.profitUnit = "";
				} else {
					this.profitUnit = profitUnit;
				}
				if(null == eventType || eventType.length() == 0) {
					this.eventType = "01";
				} else {
					this.eventType = eventType;
				}

				catLog.info("Parameter of post to SendLongSM web service :"
									+ " userName = " + this.userName
									+ ", campaignedId = " +  this.campaignedId
									+ ", payBranch = " + this.payBranch
									+ ", phoneNo = " + this.phoneNo
									+ ", smBody = " + this.smBody
									+ ", mask = " + this.mask
									+ ", maskSmBody = " + this.maskSmBody
									+ ", smType = " + this.smType
									+ ", forceSend = " + this.forceSend
									+ ", orderTime = " + this.orderTime
									+ ", exprieTime = " + this.exprieTime
									+ ", channel = W"
									+ ", sysId = " + this.sysId
									+ ", clientId = " + this.clientId
									+ ", customerId = " + this.customerId
									+ ", profitUnit = " + this.profitUnit
									+ ", eventType = " + this.eventType
									+ ", replyKafkaServer = " + this.replyKafkaServer
									+ ", replyTopic = " + this.replyTopic
									);
				
				logInfo += "Parameter of post to SendLongSM web service :" + " userName = " + this.userName
																		   + ", campaignedId = " +  this.campaignedId
																		   + ", payBranch = " + this.payBranch
						  												   + ", phoneNo = " + this.phoneNo
						   												   + ", smBody = " + this.smBody
																	       + ", mask = " + this.mask
																		   + ", maskSmBody = " + this.maskSmBody
																		   + ", smType = " + this.smType
																		   + ", forceSend = " + this.forceSend
																		   + ", orderTime = " + this.orderTime
																		   + ", exprieTime = " + this.exprieTime
																		   + ", channel = W"
																		   + ", sysId = " + this.sysId
																		   + ", clientId = " + this.clientId
																			+ ", customerId = " + this.customerId
																			+ ", profitUnit = " + this.profitUnit
																			+ ", eventType = " + this.eventType
																		   + ", replyKafkaServer = " + this.replyKafkaServer
																		   + ", replyTopic = " + this.replyTopic;
				ThreadContext.put("reqOut", "userName = " + this.userName
										+ ", campaignedId = " +  this.campaignedId
										+ ", payBranch = " + this.payBranch
										+ ", phoneNo = " + this.phoneNo
										+ ", smBody = " + this.smBody
										+ ", mask = " + this.mask
										+ ", maskSmBody = " + this.maskSmBody
										+ ", smType = " + this.smType
										+ ", forceSend = " + this.forceSend
										+ ", orderTime = " + this.orderTime
										+ ", exprieTime = " + this.exprieTime
										+ ", channel = W"
										+ ", sysId = " + this.sysId
										+ ", clientId = " + this.clientId
										+ ", customerId = " + this.customerId
										+ ", profitUnit = " + this.profitUnit
										+ ", eventType = " + this.eventType
										+ ", replyKafkaServer = " + this.replyKafkaServer
										+ ", replyTopic = " + this.replyTopic);
				

				if(this.smBody.length() <= 70) {
					catLog.info("Post to SendSM web service");
					try {
						port.sendSMV3(this.userName,
										this.SRT,
										this.campaignedId,
										this.payBranch,
										this.profitUnit,
										this.phoneNo,
										this.smBody,
										this.mask,
										this.maskSmBody,
										this.smType,
										this.eventType,
										this.forceSend,
										this.orderTime,
										this.exprieTime,
										"W",
										this.sysId,
										this.clientId,
										this.customerId,
										this.replyKafkaServer,
										this.replyTopic,
										sendSMResult,
										sendResult,
										esunMsgId,
										ispMsgId,
										statusCode,
										errorMsg);
						catLog.info("port.sendSM_V3(" + this.userName + ", "
														+ this.SRT + ", "
														+ this.campaignedId + ", "
														+ this.payBranch + ", "
														+ this.phoneNo + ", "
														+ this.smBody + ", "
														+ this.mask + ", "
														+ this.maskSmBody + ", "
														+ this.smType + ", "
														+ this.forceSend + ", "
														+ this.orderTime + ", "
														+ this.exprieTime + ", "
														+ "W" + ", "
														+ this.sysId + ", "
														+ this.clientId + ", "
														+ this.customerId + ", "
														+ this.profitUnit + ", "
														+ this.eventType + ", "
														+ this.replyKafkaServer + ", "
														+ this.replyTopic + ", "
														+ sendSMResult.value + ", "
														+ sendResult.value + ", "
														+ esunMsgId.value + ", "
														+ ispMsgId.value + ", "
														+ statusCode.value + ", "
														+ errorMsg.value +");"
						);

					} catch (Exception e) {
						catLog.error("sendSM_V3 occurs Exception, ");
						e.printStackTrace();

						StringWriter sw = new StringWriter();
						PrintWriter pw = new PrintWriter(sw);
						e.printStackTrace(pw);
						String tmp = sw.toString();
						JsonObject tmpJson = new JsonObject();
						tmpJson.addProperty("test", tmp);
						tmp = tmpJson.get("test").toString();
						tmp = tmp.substring(1, tmp.length()-1);
						catLog.error(tmp);
						catLog.error(sw.toString());
					}
//					port.sendSM(this.userName, this.SRT, this.campaignedId, this.payBranch, this.phoneNo, this.smBody, this.smType, this.forceSend, this.orderTime, this.exprieTime, sendSMResult, sendResult, esunMsgId, ispMsgId, statusCode, errorMsg);
				}else {
					catLog.info("Post to SendLongSM web service");
					try {
						port.sendLongSMV3(this.userName,
								this.SRT,
								this.campaignedId,
								this.payBranch,
								this.profitUnit,
								this.phoneNo,
								this.smBody,
								this.mask,
								this.maskSmBody,
								this.smType,
								this.eventType,
								this.forceSend,
								this.orderTime,
								this.exprieTime,
								"W",
								this.sysId,
								this.clientId,
								this.customerId,
								this.replyKafkaServer,
								this.replyTopic,
								sendSMResult,
								sendResult,
								esunMsgId,
								ispMsgId,
								statusCode,
								errorMsg);
						catLog.info("port.sendLongSM_V3(" + this.userName + ", "
															+ this.SRT + ", "
															+ this.campaignedId + ", "
															+ this.payBranch + ", "
															+ this.phoneNo + ", "
															+ this.smBody + ", "
															+ this.mask + ", "
															+ this.maskSmBody + ", "
															+ this.smType + ", "
															+ this.forceSend + ", "
															+ this.orderTime + ", "
															+ this.exprieTime + ", "
															+ "W" + ", "
															+ this.sysId + ", "
															+ this.clientId + ", "
															+ this.customerId + ", "
															+ this.profitUnit + ", "
															+ this.eventType + ", "
															+ this.replyKafkaServer + ", "
															+ this.replyTopic + ", "
															+ sendSMResult.value + ", "
															+ sendResult.value + ", "
															+ esunMsgId.value + ", "
															+ ispMsgId.value + ", "
															+ statusCode.value + ", "
															+ errorMsg.value +");"
						);
					} catch (Exception e) {
						catLog.error("sendLongSM_V3 occurs Exception, ");
						e.printStackTrace();

						StringWriter sw = new StringWriter();
						PrintWriter pw = new PrintWriter(sw);
						e.printStackTrace(pw);
						String tmp = sw.toString();
						JsonObject tmpJson = new JsonObject();
						tmpJson.addProperty("test", tmp);
						tmp = tmpJson.get("test").toString();
						tmp = tmp.substring(1, tmp.length()-1);
						catLog.error(tmp);
						catLog.error(sw.toString());
					}
//					port.sendLongSM(this.userName, this.SRT, this.campaignedId, this.payBranch, this.phoneNo, this.smBody, this.smType, this.forceSend, this.orderTime, this.exprieTime, sendSMResult, sendResult, esunMsgId, ispMsgId, statusCode, errorMsg);
				}
				catLog.info("End SendLongSM web service");
				
				if(null != getSendSMResult()) {
					res.setSendSMResult(getSendSMResult());
					res.setSendResult(getSendResult());
					res.setEsunMsgId(getEsunMsgId());
					res.setIspMsgId(getIspMsgId());
					res.setStatusCode(getStatusCode());
					res.setErrorMsg(getErrorMsg());
				} 

			}
		}
		
		result = gson.toJson(res);
		String tmp = result;
		JsonObject tmpJson = new JsonObject();
		tmpJson.addProperty("test", tmp);
		tmp = tmpJson.get("test").toString();
		tmp = tmp.substring(1, tmp.length()-1);
		if(logInfo.length()>15)logInfo += ", ";
		logInfo += "response : " + tmp;
		ThreadContext.put("respOut", tmp);

		endTime = System.currentTimeMillis();
		ThreadContext.put("execTimeOut", "SMS execute time: " + (endTime-startTime)+" ms");
        catLogOut.info("");
		
		catLog.info("End SendSm service");
		
		return result;
	}
	
	public String SearchSm(String EsunMsgId, String ispMsgId) {
		catLog.info("Call get SearchSm service");
		startTime = System.currentTimeMillis();
		ResponseModel res = new ResponseModel();
		String result = "", logInfo = "[SearchSms]";
		if((null == EsunMsgId || EsunMsgId.length() == 0) && (null == ispMsgId || ispMsgId.length() == 0)) {
			catLog.error("EsunMsgId and IspMsgId cannot be blank at the same time");
			res.setStatusCode(ErrorCode.SERVER_RTN_GENERAL_ERROR);
			res.setErrorMsg("EsunMsgId and IspMsgId cannot be blank at the same time");
		}else {
			
			catLog.info("Post to qrySendStatus web service");
			logInfo += "Parameter of post to qrySendStatus web service : userName = " 
					   + this.userName + " EsunMsgId = " +  EsunMsgId + " ispMsgId = " + ispMsgId;

			ThreadContext.put("reqOut", "userName = " + this.userName + " EsunMsgId = " +  
											EsunMsgId + " ispMsgId = " + ispMsgId);

			try {
				port.qrySendStatus(this.userName, this.SRT, EsunMsgId, ispMsgId, sendSMResult, sendResult, sendStatus, statusCode, statusFlag, errorMsg);
			} catch (Exception e) {
				catLog.error("qrySendStatus occurs Exception, ");
				e.printStackTrace();

				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw);
				e.printStackTrace(pw);
				String tmp = sw.toString();
				JsonObject tmpJson = new JsonObject();
				tmpJson.addProperty("test", tmp);
				tmp = tmpJson.get("test").toString();
				tmp = tmp.substring(1, tmp.length()-1);
				catLog.error(tmp);
				catLog.error(sw.toString());
			}

			catLog.info("End qrySendStatus web service");

			
			if(null != getSendSMResult()) {
				res.setSendSMResult(getSendSMResult());
				res.setSendResult(getSendResult());
				res.setSendStatus(getSendStatus());
				res.setStatusCode(getStatusCode());
				res.setSendFlag(getStatusFlag());
				switch(getStatusFlag()) {
		    		case "0" : res.setMsg("Reservation transfer");break;
		    		case "1" : res.setMsg("Delivered");break;
		    		case "2" : res.setMsg("Delivered");break;
		    		case "3" : res.setMsg("Delivered");break;
		    		case "4" : res.setMsg("Has been delivered to the phone");break;
		    		case "5" : res.setMsg("The content is wrong");break;
		    		case "6" : res.setMsg("The phone number is wrong");break;
		    		case "7" : res.setMsg("The newsletter has been deactivated");break;
		    		case "8" : res.setMsg("Overtime without delivery");break;
		    		case "9" : res.setMsg("Appointment cancelled");break;
		    		default : res.setMsg("No expected error");break;
				}
				res.setErrorMsg(getErrorMsg());
			}
		}
		
		result = gson.toJson(res);
		
		String tmp = result;
		JsonObject tmpJson = new JsonObject();
		tmpJson.addProperty("test", tmp);
		tmp = tmpJson.get("test").toString();
		tmp = tmp.substring(1, tmp.length()-1);
		if(logInfo.length()>15)logInfo += ", ";
		logInfo += "response : " + tmp;
		ThreadContext.put("respOut", tmp);
		endTime = System.currentTimeMillis();
		if(ThreadContext.get("execTimeOut")!=null) {
			ThreadContext.remove("execTimeOut");
		}
		ThreadContext.put("execTimeOut", "SMS execute time: " + (endTime-startTime)+" ms");
        catLogOut.info("");
		
		catLog.info("End SearchSm service");
		return result;
	}
	
	private static boolean isValidDate(String str) {
        boolean convertSuccess = true;
        //SimpleDateFormat inFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat outFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        try {
        	//Date date = inFormat.parse(str);
        	outFormat.setLenient(false);
        	outFormat.parse(str);
            //outFormat.format(date);
            //System.out.println(outFormat.format(date));
        } catch (ParseException e) {
            convertSuccess = false;
        }
        return convertSuccess;
	}
	
	protected SmsWebService initSmsWebService() {
		SmsWebService smsWebService = null;
		try {
			catLog.info("init web service");
			catLog.info("wsdlURL: " + wsdlURL);
			catLog.info("service name: " + SERVICE_NAME);

			smsWebService =  new SmsWebService(this.wsdlURL, SERVICE_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return smsWebService;
	}
	
	protected SmsWebServiceSoap initSmsWebServiceSoap() {
		SmsWebServiceSoap smsWebServiceSoap = null;
		try {
			smsWebServiceSoap =  ss.getSmsWebServiceSoap();
		} catch (Exception e) {
			catLog.error("qrySendStatus occurs Exception, ");
			e.printStackTrace();

			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String tmp = sw.toString();
			JsonObject tmpJson = new JsonObject();
			tmpJson.addProperty("test", tmp);
			tmp = tmpJson.get("test").toString();
			tmp = tmp.substring(1, tmp.length()-1);
			catLog.error(tmp);
			catLog.error(sw.toString());
		}
		return smsWebServiceSoap;
	}

	public Boolean getSendSMResult() {
		return sendSMResult.value;
	}

	public String getSendResult() {
		return sendResult.value;
	}

	public String getEsunMsgId() {
		return esunMsgId.value;
	}

	public String getIspMsgId() {
		return ispMsgId.value;
	}

	public String getStatusCode() {
		return statusCode.value;
	}

	public String getErrorMsg() {
		return errorMsg.value;
	}

	public String getStatusFlag() {
		return statusFlag.value;
	}

	public String getSendStatus() {
		return sendStatus.value;
	}

}
